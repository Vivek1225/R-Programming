a <- c(1:5)
#cumsum function is used to calculate the cummulative
#sum of the passed arguments.
cat("Cumulative sum of 1 to 10 nubers is: ", cumsum(1:10), "\n")
# print(cumsum(-1:-5))
# print(cumsum(a))
# a1 <- c(17, 25, 98, 56)
# print(cumsum(a1))