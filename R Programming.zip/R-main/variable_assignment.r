a = 12
b <- 33
"VVIT " -> college
cat("Values are : ", a, b, college, "")