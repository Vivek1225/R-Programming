vector <- c(11, 36, 03, 76, 10)
number <- factor(vector, ordered = TRUE)
print(number)
print(is.factor(number))