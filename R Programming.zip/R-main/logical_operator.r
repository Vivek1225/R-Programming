a <- 1
b <- 2
if (a == 1 && b == 2) {
  print("true")
}
if (a > 0 && b < 0) {
  print("possible")
}
