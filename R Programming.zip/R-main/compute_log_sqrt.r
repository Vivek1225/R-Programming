a <- as.integer(50)
ans <- log10(sqrt(a))
cat("The computed value is ", ans, "\n")