n <- as.integer(readline("Enter number:"))
a <- seq(1:n)
#rev function is used to reverse the elements of a vector object.
cat("The numbers in reverse order are:", rev(a), "\n")