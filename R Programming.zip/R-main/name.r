x <- readline("Enter your first name: ")#readline stores in character type
y <- readline("Enter your last name: ")
#printing using cat(concatenation)
cat("My full name is ", x, y, "\n")